
public class TestHarness {

	public static void GenerateSheep() {
		// public Sheep(String sName, String sFavColor, int sheight, int sweight)
//		Sheep s = new Sheep("Bill", "Orange", 62,34);
//		System.out.println("**** ----  Adding a sheep:");
//		(ListOfSheep.SheepRoster).add(s);	
		

		// Declaring an array of sheep
        Sheep[] sheepArray;
        
        // Allocating memory for 10 objects
        // of type student
        sheepArray = new Sheep[10];
 
        // Initializing 10 elements of array 
        sheepArray[0] = new Sheep("Bill", "Orange", 62,34);
        sheepArray[1] = new Sheep("will", "Orange", 62,34);
        sheepArray[2] = new Sheep("dill", "Orange", 62,34);
        sheepArray[3] = new Sheep("zill", "Orange", 62,34);
        sheepArray[4] = new Sheep("kill", "Orange", 62,34);
        sheepArray[5] = new Sheep("sill", "Orange", 62,34);
        sheepArray[6] = new Sheep("till", "Orange", 62,34);
        sheepArray[7] = new Sheep("rill", "Orange", 62,34);
        sheepArray[8] = new Sheep("jill", "Orange", 62,34);
        sheepArray[9] = new Sheep("pill", "Orange", 62,34);
        

        for (int i = 0; i < sheepArray.length; i++) {
        	
        	(ListOfSheep.SheepRoster).add(sheepArray[i]);
    	}
		
	}
	
}
